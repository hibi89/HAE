HAE + Lightning Azent synthetic local MVP
Requires Python 3.11+; no Git, pip or separate LA required at runtime.
Start: double-click run-bundled.cmd
Native Windows release check: double-click VERIFY-WINDOWS.cmd
Synthetic HTTP/SQLite check only: run-bundled.cmd --verify
Only synthetic CSV data is supported.
