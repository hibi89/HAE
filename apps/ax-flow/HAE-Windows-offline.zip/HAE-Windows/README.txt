HAE + Lightning Azent synthetic local MVP
Requires Python 3.11+. No Git or pip required.
Extract the ZIP. Double-click run-bundled.cmd to start.
To verify without modifying user files: run-bundled.cmd --verify
Only synthetic CSV inputs are supported.
