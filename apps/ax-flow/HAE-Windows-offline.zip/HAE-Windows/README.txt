HAE + Lightning Azent synthetic local MVP
Requires Python 3.11+; no Git/pip/network at runtime.
Start: double-click run-bundled.cmd
Check Windows/NTFS: double-click VERIFY-WINDOWS.cmd
HTTP/SQLite test only: run-bundled.cmd --verify
Only synthetic CSV data is supported.
